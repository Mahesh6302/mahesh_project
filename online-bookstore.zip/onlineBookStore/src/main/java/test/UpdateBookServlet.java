package test;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.util.*;
@SuppressWarnings("serial")
@WebServlet("/update")
public class UpdateBookServlet extends HttpServlet{
   @SuppressWarnings("unchecked")
   protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
	   HttpSession  hs = req.getSession();
	   if(hs==null) {
		   req.setAttribute("msg","Session Expired...<br>");
		   req.getRequestDispatcher("Home.jsp").forward(req, res);
	   }else {
		   String bCode = req.getParameter("bCode");
		   ArrayList<BookBean> al = (ArrayList<BookBean>)hs.getAttribute("alist");
		   BookBean bb = null;
		   Iterator<BookBean> it = al.iterator();
		   while(it.hasNext()) {
			   bb = it.next();
			   if(bCode.equals(bb.getCode())) {
				   break;
			   }
		   }
		   bb.setPrice(Float.parseFloat(req.getParameter("bprice")));
		   bb.setQty(Integer.parseInt(req.getParameter("bqty")));
		   int k = new UpdateBookDetailsDAO().update(bb);
		   if(k>0) {
			   req.setAttribute("msg","Book Details updated suuccessfully...<br>");
			   req.getRequestDispatcher("Update.jsp").forward(req, res);
		   }
	   }
   }
	
	
}
