package test;
import java.sql.*;
public class GetBookDao{
	public BookBean  bb= null;
    public BookBean getBookDetails(String code,String Name) {
    	try {
    		Connection con = DBConnection.getCon();
    		PreparedStatement ps = con.prepareStatement("select * from BookDetails57 where code=? and Name=?");
			ps.setString(1, code);
			ps.setString(2, Name);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
			BookBean bb = new BookBean();
				bb.setCode(rs.getString(1));
				bb.setAuthor(rs.getString(2));
				bb.setName(rs.getString(3));
				bb.setPrice(rs.getFloat(4));
				bb.setQty(rs.getInt(5));
				 
				 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return bb;
    	}
 }

