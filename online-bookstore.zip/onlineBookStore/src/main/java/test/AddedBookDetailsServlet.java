package test;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@SuppressWarnings("serial")
@WebServlet("/add")
public class AddedBookDetailsServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession hs = req.getSession(false);
		if (hs == null) {
			req.setAttribute("msg", "session Expired....<br>");
			RequestDispatcher rd = req.getRequestDispatcher("Home.jsp");
		} else {
			BookBean bb = new BookBean();
			bb.setCode(req.getParameter("code"));
			bb.setName(req.getParameter("name"));
			bb.setAuthor(req.getParameter("author"));
			bb.setPrice(Float.parseFloat(req.getParameter("price")));
			bb.setQty(Integer.parseInt(req.getParameter("qty")));
			System.out.println("**************************");
			// System.out.println(bb.getAuthor());
			// String s1=req.getParameter("name");
			// System.out.println(s1);
			int k = new AddBookDetailsDAO().insert(bb);

			if (k > 0) {
				RequestDispatcher rd = req.getRequestDispatcher("AddBookDetails.jsp");
				rd.forward(req, res);
				// System.out.println(bb.getAuthor());
			}

		}
	}
}
