package test;
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
@SuppressWarnings("serial")
@WebServlet("/delete")
public class DeleteBookServlet extends HttpServlet
{
	@SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
		HttpSession hs = req.getSession(false);
		if(hs==null) {
			req.setAttribute("msg","Session expired..<br>");
			req.getRequestDispatcher("Home.jsp").forward(req, res);
		}else {
			String bCode = req.getParameter("bCode");
			ArrayList<BookBean> al  = (ArrayList<BookBean>)hs.getAttribute("alist");
			BookBean bb  = null;
			Iterator<BookBean>it  = al.iterator();
			while(it.hasNext())
			{
				bb = it.next();
				if(bCode.equals(bb.getCode()))
				{
					break;
				}
			}
			int k  =new DeleteBookDAO().delete(bb);
			if(k>0) {
				req.setAttribute("bbean",bb);
				req.getRequestDispatcher("DeleteBook.jsp").forward(req, res);
			}
		}
	}
}
