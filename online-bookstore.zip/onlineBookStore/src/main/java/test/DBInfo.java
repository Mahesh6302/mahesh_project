package test;
public interface DBInfo {
public static final String
dbUrl="jdbc:oracle:thin:@localhost:1521:orcl";
public static final String uName="d##mahesh11";
public static final String pWord="mahesh6302";
}
